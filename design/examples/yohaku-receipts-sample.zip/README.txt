YOHAKU UI demo. Fictional receipt images. Return a yohaku.receipt-items JSON file, retaining book_id, record_id and receipt_id. Do not create bookkeeping transactions.
